def bt13():
    n = int(input("Nhập n: "));
    for i in range(1 ,n):
        print(i, end="  ");
    print();

def bt14():
    n = int(input("Nhập số n: "));
    for i in range (1,11):
        print(f"{n} * {i} = {n*i}");

def bt15():
    n = int(input("Nhập n: "));
    for row in range(n ,0 , -1 ):
        for column in range(row, 0,-1):
            print(column, end=" ");
        print("");

def bt16():
    n = int(input("Nhập n: "));
    i = 0;
    while(i<=n):
        print(i, end=" ");
        i+=1
    print();

def bt17():
    number1= 1; 
    number2= 1;
    temp = 0;
    i = 3;
    n = int(input("Nhập số n (Fibonacci): "));
    if(n == 0):
        print("0");
    if(n==1 or n == 2):
        print("0 1");
    print("0 1 1", end=" ");
    while(i <= n):
        temp = number1 + number2;
        number1 = number2;
        number2 = temp;
        print(f"{temp}",end=" ");
        i+=1
def bt18():
    n = int(input("Nhập số n (Giai  thừa): "));
    number = 1
    for i in range(1, n + 1):
        number = number * i;
    print(number);

def bt19():
    n = int(input("Nhập số n: "));
    new_number = 0;
    while(n>0):
        remainder = n % 10;
        print(remainder,end="");
        n =int(n / 10);
        new_number = new_number * 10 + remainder;
    print();

def bt20():
    n = int(input("Nhập số n: "));
    i = 1;
    result = 0;
    while(i<=n):
        result = result + 1/i;
        i+=1;
        print(result);

def bt21():
    number1 = int(input("Nhập số a: "));
    number2 = int(input("Nhập số b: "));
    a = 0;
    temp = 0;
    while(number1 > 0):
        if(number1<number2):
            temp = number1;
            number1 = number2;
            number2 = temp;
        a = number1 % number2;
        number1 = a;
    print(number2);

def bt22():
    number1 = int(input("Nhập số tiền hiện có: "));
    number2 = int(input("Nhập số tiền mơ ước: "));
    monthCounter = 0;
    new = 0;
    lai = (number1 * 3 / 100)
    while(number1 < number2):
        new = number1 + lai;
        monthCounter+=1;
        number1 = new;
    print(f"Số tháng cần đạt số tiền mơ ước là {monthCounter}")
def main():
    bt22();


if __name__ == "__main__":
    main();
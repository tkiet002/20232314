import math

def bt1(): #tính chu vi diện tích hình chữ nhật
    chieudai = int(input("Nhập chiều dài."));
    chieurong = int(input("Nhập chiều rộng."));
    if(chieudai <= 0 or chieurong <= 0):
        print("Độ dài một cạnh không thể bằng 0 hoặc nhỏ hơn 0")
    chuvi = (chieudai + chieurong) * 2;
    dientich = chieudai*chieurong;
    print(f"Chu vi: {chuvi} và Diện tích {dientich}");

def bt2():
    a = int(input("Nhập cạnh a:"));
    b = int(input("Nhập cạnh b:"));
    c = int(input("Nhập cạnh c:"));
    p = (a + b + c) / 2;
    heron = math.sqrt(p*(p-a)*(p-b)*(p-c));
    print(f"Diện tích tam giác = {heron}")
    
def bt3():
    a = int(input("Nhập số a:"));
    b = int(input("Nhập số b:"));
    print(f"a+b = {a + b}; a-b = {a-b} ; b-a={b-a};");
    try:
        c = a % b;
        d = a / b;
        print(f"a+b = {a + b}; a-b = {a-b} ; b-a={b-a}; a % b = {c}; a / b = {d}");
    except:
        print("Input Error!! số chia không thể bằng 0")

def bt4():
    a = int(input("Nhập số a:"));
    b = int(input("Nhập số b:"));
    c = int(input("Nhập số c:"));
    array = [a,b,c];
    array.sort();
    print(array[0]);
        
def bt5():
    a = int(input("Nhập số a:"));
    b = int(input("Nhập số b:"));
    c = int(input("Nhập số c:"));
    d = int(input("Nhập số d:"));
    temp = a;
    for i in [a,b,c,d]:
        if(temp > i):
            temp = i;
    print(temp)

def bt6():
    a = float(input("Nhập số a:"));
    b = float(input("Nhập số b:"));
    c = float(input("Nhập số c:"));
    d = float(input("Nhập số d:"));
    temp = a;
    for i in [a,b,c,d]:
        if(i < temp):
            temp = i;
    print(temp);

def bt7():
    dtb = float(input("Nhập điểm trung bình."));
    if(dtb < 5):
        print("Kém");
    elif(dtb >=5 and dtb<=7):
        print("Trung bình");
    elif(dtb>7  and dtb<=8):
        print("Khá");
    elif(dtb>8  and dtb<=9.5):
        print("Giỏi");
    elif(dtb>9.5):
        print("Xuất sắc");
    else:
        print("Không xếp hạng thang điểm này.");

def bt8():
    years = int(input("Nhập năm: "));
    if(years % 4 == 0 or years % 400 == 0):
        print("Là năm nhuận");

def bt9():
    years = int(input("Nhập năm: (Nhập số) "));
    month = int(input("Nhập tháng: (Nhập số) "));
    if((years % 4 == 0 or years % 400 == 0) and month == 2):
        print(f"{month}/{years} có 29 ngày");
    else:
        match month:
            case 1,3,5,7,8,10,12:
                print(f"{month} có 31 ngày.");
            case 2:
                print(f"{month}/{years} có 28 ngày.");
            case 4,6,9,11:
                print(f"{month}/{years} có 30 ngày.");

def bt10():
    print("Giải phương trình ax + b = 0");
    a = int(input("Nhập số a: "));
    b = int(input("Nhập số b: "));
    if(a==0):
        print(f"vô nghiệm");
    else:
        print(f"x = {-b/a}");

def bt11():
    print("Giải phương trình ax^2 + bx + c= 0");
    a = int(input("Nhập số a: "));
    b = int(input("Nhập số b: "));
    c = int(input("Nhập số c: "));
    delta = b**2 - 4*a*c;
    if(a == 0):
        if(b==0 and c==0):
            print("Vô cùng.");
        else:
            print(f"Có 1 nghiệm là {-c/b}");
    elif(delta < 0):
        print(f"Phương trình vô nghiệm");
    elif(delta == 0):
        print(f"x1 = x2 = {-b/2*a}");
    elif(delta >0):
        x1 = -(b + math.sqrt(delta))/(2*a);
        x2 = -(b - math.sqrt(delta))/(2*a);
        print(f"Phương trình có 2 nghiệm phân biệt {x1} và {x2}");
if __name__ == "__main__":
    bt11();
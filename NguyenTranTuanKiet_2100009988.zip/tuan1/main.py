from lab1 import count_to_milion
import random
def main():
    count_to_milion();


if __name__ == "__main__":
    main();

# cách hoạt động của python 
#   1. Python là một ngôn ngữ phiên dịch, dynamically type language - ngôn ngữ lập trình động - một ngôn ngữ lập trình bậc cao.
#   2. Phiên dịch từng dòng từ trái sang phải, từ trên xuống dưới.
#   3. Python không cần ta phải khai báo kiểu dữ liệu biến
#   4. khi gọi python <file.py> thì nó chạy theo đường dẫn từ biến $PATH ta khai  sẵn ở hệ điều hành
#   5. venv là một môi trường ảo, riêng biệt, cho ta không cần thiết phải cài các thư viên một cách toàn cục (global) 
